package com.lmj.server.test;

import java.io.IOException;

import com.lmj.server.util.HttpClient;
import com.lmj.server.util.HttpHeader;
import com.lmj.server.util.HttpParamers;

public class Test {

	public static void main(String[] args) throws IOException {
		// TODO 自动生成的方法存根
		/*设置必须的请求头信息*/
		HttpHeader headers = new HttpHeader();
		headers.addParam("Authorization", "Basic bGltZW5nanVuMDAyQGdtYWlsLmNvbToxMzYxMDQxNC5MaQ==");
		
		String targetURL = "https://ruh.cloudsigma.com/api/2.0/servers/a31314ea-6f67-41b9-8677-28fc2442dc54/action/?do=start";
		// TODO 自动生成的方法存根
		HttpParamers Paramers = HttpParamers.httpPostParamers();
		String jieguo = HttpClient.doPost(targetURL, Paramers, headers, 10000, 10000);
		
		System.out.println(jieguo);
	}

}
