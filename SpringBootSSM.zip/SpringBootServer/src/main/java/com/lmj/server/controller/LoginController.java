package com.lmj.server.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lmj.server.bean.Msg;
import com.lmj.server.beans.dao.UserVO;
import com.lmj.server.service.LoginService;

@Controller
public class LoginController {
	@Autowired
	private LoginService loginService;
	
    
	@CrossOrigin(allowCredentials = "true")
	@RequestMapping("/hello")
	@ResponseBody //返回json
	public Msg hello(HttpServletRequest request,HttpServletResponse response){
			return Msg.ok().add("hello","你好~!");
	}
	
	@CrossOrigin(allowCredentials = "true")
	@RequestMapping("/login")
	@ResponseBody //返回json
	public Msg login(HttpServletRequest request,HttpServletResponse response){
		    String email = request.getParameter("email");
		    String password = request.getParameter("password");
		    UserVO uservo = loginService.login(email, password,request);
		    if(uservo!=null){
		    	return Msg.ok().add("token",request.getAttribute("token")).add("user",uservo);
		    }else{
		    	return Msg.badRequest().add("error", "账号或者密码错误！");
		    }
	}
}
