package com.lmj.server.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.lmj.server.interceptor.TokenInterceptor;

@Configuration
public class InterceptorConfig  extends WebMvcConfigurerAdapter{

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		// TODO 自动生成的方法存根
		registry.addInterceptor(new TokenInterceptor())
		.addPathPatterns("/**")//拦截所有请求
		.excludePathPatterns("/hello")//指定hello不需要拦截
		;
		super.addInterceptors(registry);
	}

}
