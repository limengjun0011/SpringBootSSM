package com.lmj.server.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lmj.server.JWT.JWT;
import com.lmj.server.bean.Login;
import com.lmj.server.bean.User;
import com.lmj.server.bean.UserExample;
import com.lmj.server.beans.dao.UserVO;
import com.lmj.server.mapper.UserMapper;


@Service
public class LoginService {
	@Autowired
	private UserMapper userMapper;
	
	
	public UserVO login(String email,String password,HttpServletRequest request){
		List<User> userList = new ArrayList<User>();
		UserVO uservo = new UserVO();
		UserExample use = new UserExample();
		use.createCriteria().andEmailEqualTo(email.trim()).andPassEqualTo(DigestUtils.md5Hex(password.trim()));
		userList = userMapper.selectByExample(use);
		if(userList.size()>0){
			BeanUtils.copyProperties(userList.get(0),uservo);
			uservo.setPass(null);
			Login login = new Login();
			login.setEmail(uservo.getEmail());
			login.setId(uservo.getId());
			login.setPass(uservo.getPass());
			String token = JWT.sign(login, 60L * 1000L * 30L); // 有效期30分钟
			request.setAttribute("token", token);
			return uservo;
		}
		return null;
	}
	
	
	

}
