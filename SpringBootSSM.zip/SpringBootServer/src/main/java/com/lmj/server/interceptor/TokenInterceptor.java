package com.lmj.server.interceptor;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.lmj.server.JWT.JWT;
import com.lmj.server.JWT.Login;
import com.lmj.server.bean.Msg;


public class TokenInterceptor implements HandlerInterceptor{
	
	@Override
	 public void afterCompletion(HttpServletRequest request,
	            HttpServletResponse response, Object handler, Exception arg3)
	            throws Exception {
	    }
	@Override
	    public void postHandle(HttpServletRequest request, HttpServletResponse response,
	            Object handler, ModelAndView model) throws Exception {
	    }

	    //拦截每个请求
	    @Override
	    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
	            Object handler) throws Exception {
	        response.setStatus(200);
	        response.setCharacterEncoding("utf-8");
	        String token = request.getParameter("token");
	        Msg msg = Msg.ok();
	        //token不存在
	        if(null != token) {
	            Login login = JWT.unsign(request,token, Login.class);
	            if(null != login&&login.getEmail()!=null) {
	            	if(request.getAttribute("shuaxin")!=null&&request.getAttribute("shuaxin").equals("1")){//说明token不足25分钟，刷新新的token
	            		request.setAttribute("token", JWT.sign(login,60L* 1000L* 30L));
	            	}
	            	 request.setAttribute("id",login.getId());
	                 return true;
	            }
	            else
	            {
	                response.setStatus(401);
	                msg = Msg.forbidden();
	                responseMessage(response, response.getWriter(), msg,request);
	                return false;
	            }
	        }
	        else
	        {
	            msg = Msg.forbidden();
	            responseMessage(response, response.getWriter(), msg,request);
	            return false;
	        }
	    }

	    //请求不通过，返回错误信息给客户端
	    private void responseMessage(HttpServletResponse response, PrintWriter out, Msg msg,HttpServletRequest request) {
	    	msg = Msg.forbidden();
	        response.setContentType("application/json; charset=utf-8");  
	        response.setHeader("Access-Control-Allow-Origin", request.getHeader("Origin"));
	        response.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS,PUT,DELETE");
	        response.setHeader("Access-Control-Allow-Headers", ((HttpServletRequest) request).getHeader("Access-Control-Request-Headers"));
	        response.setHeader("Access-Control-Allow-Credentials", "true");
	        String json = JSONObject.toJSONString(msg);
	        out.print(json);
	        out.flush();
	        out.close();
	    }
}
