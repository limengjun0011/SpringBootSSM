package com.lmj.server.util;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.Session;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * java 远程执行linux命令
 */
public class SshUtil {
    public static void main(String[] args) throws IOException {
        String remoteCommand = "find /etc/dnat -name \"conf\" | xargs perl -pi -e 's|30212>34.81.104.157:80|30212>34.81.104.157:81|g'";
        RemoteSubmitCommand(remoteCommand);
//        submitModelDataSync(localCommand);
    }

    /**
     * 远程执行 linux 命令
     */
    private static void RemoteSubmitCommand(String command) {
    	// 设置主机IP地址
        Connection c = new Connection("101.91.224.194");
        StringBuilder buffer = new StringBuilder();
        try {
            c.connect();
            // 设置登录名称和登录密码
            boolean flag = c.authenticateWithPassword("root", "zi7uy57MT7XJvQRn");
            System.out.println(flag);
            Session session = c.openSession();
            session.execCommand(command);

            BufferedReader br = new BufferedReader(new InputStreamReader(session.getStdout(), "UTF-8"));

            String line = null;
            while ((line = br.readLine()) != null) {
                System.out.println("line:" + line);
                buffer.append(line).append("\n");
            }

            System.out.println("end");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * 本地执行 shell 命令 包括java shell python
     */
    public static Boolean submitModelDataSync(String command) throws IOException {
        boolean flag = true;
        try {
            final Process process = Runtime.getRuntime().exec(command);
            BufferedReader br1 = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            long startTime = System.currentTimeMillis() / 1000;
            while (true) {
                long endTime = System.currentTimeMillis() / 1000;
                if (endTime - startTime > 10000000) {
                    return false;
                }
                String line = br1.readLine();
                if (line.contains("success")) {
                    flag = true;
                    break;
                }
                if (line.contains("Error") || line.contains("error")) {
                    flag = false;
                    break;
                }
            }
            br1.close();
        } catch (Exception e) {
        }
        return flag;
    }
}


